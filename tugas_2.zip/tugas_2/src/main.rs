use std::collections::HashMap;
use std::io;
use chrono::prelude::*;

#[derive(Debug, Clone)]
struct Account {
    id: String,
    name: String,
    time: i32
}

struct Accounts {
    inner: HashMap<String,Account>
}
impl Accounts {
    fn new() -> Self {
        Self{
            inner:HashMap::new(),
        }
    }
    
    fn add(&mut self, account: Account){
        self.inner.insert(account.name.clone(), account);
    }

    fn get_all(&self) -> Vec<&Account>{
        let mut accounts = vec![];
        for account in self.inner.values(){
            accounts.push(account)
        }
        accounts
    }

    fn delete(&mut self, id : &str)-> bool{
        self.inner.remove(id).is_some()
    }

    fn update(&mut self, id: &str, name: &str, time: i32) -> bool {
        match self.inner.get_mut(id){
            Some(account)=>{
                account.time = time;    
                true
            },
            None => false
        }
    }
    
}

fn time_update() -> Option<i32> {
    println!("Time >>");
    loop{
        let input = match get_input(){
            Some(input) => input,
            None => return None
        };
        if &input == ""{
            return None;
        }
        let parsed_input: Result<i32,_> = input.parse();
        match parsed_input{
            Ok(time) => return Some(time),
            Err(_) => println!("Number Only!")
        }
    }
}


fn add_account(accounts: &mut Accounts){
    println!("Id: ");
    let id = match get_input(){
        Some(input) => input,
        None => return
    };
    let name = match get_input(){
        Some(input) => input,
        None => return
    };
    let time = match time_update(){
        Some(time) => time,
        None => return
    };
    let Account = Account {id, name, time};
    accounts.add(Account);
    println!("New Account Added!");
}

fn remove_acc(accounts: &mut Accounts){
    for account in accounts.get_all(){
        println!("{:?}", account);
    }
    println!("Enter Account ID to Remove");
    let id = match get_input(){
        Some(input) =>  input,
        None => return
    };
    if accounts.delete(&id){
        println!("Account was removed!");
    } else {
        println!("Account not found!")
    }
}

fn update_acc(accounts: &mut Accounts){
    for account in accounts.get_all(){
        println!("{:?}", account);
    }
    println!("Enter Account Update!");
    let name = match get_input(){
        Some(input) => input,
        None => return
    };
    let time = match get_input(){
        Some(time) => time,
        None => return
    };
    if accounts.update(&id,&name,time){
        println!("Account Updated!")
    }else{
        println!("Account Not Found!")
    }
}

fn view(accounts:&Accounts) {
    for account in accounts.get_all(){
        println!("{:?}", account);
    }
}

fn get_input() -> Option<String> {
    let mut buffer = String::new();
    while io::stdin().read_line(&mut buffer).is_err() {
        println!("Please try again")
    }
    let input = buffer.trim().to_owned();
    if &input == "" {
        None
    } else {
        Some(input)
    }
}


fn menu(){
    fn menu_option(){
        let local: DateTime<Local> = Local::now();
        println!("");
        println!("=== Billing Manager warnet ===");
        println!("{}", local.format("Date: %Y-%m-%d").to_string());
        println!("{}", local.format("Time: %H:%M:%S").to_string());
        println!("==============================");
        println!("1. Add New Billing ");
        println!("2. View All Billing Account ");
        println!("3. Delete Billing Account ");
        println!("4. Update Billing Account ");
        println!("5. Quit Application \n ");
        println!("==============================");
      
        print!("Your Command >>");

        println!("");
    }

    loop{
        menu_option();
        let input = match get_input() {
            Some(input) => input, 
            None => return 
        };

        match input.as_str() {
            "1" => add_account(&mut accounts),
            "2" => view(&accounts),
            "3" => remove_acc(&mut accounts),
            "4" => update_acc(&mut accounts),
            "5" => break,
            _ => break,
        }

    }   
}



fn main() {
    
    menu()
}
